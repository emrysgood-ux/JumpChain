/**
 * Son of Cosmos - Database Seeding Script (CORRECTED)
 * 
 * CHANGELOG FROM ORIGINAL:
 * - Fixed Yosho birth year: 300 CE â†’ ~1262 CE (730 years old per OVA canon)
 * - Fixed Nobuyuki birth year: 1955 â†’ ~1869 (19th century per OVA canon)
 * - Fixed Nobuyuki species: Human â†’ Juraian-Human Hybrid (lives 120+ years)
 * - Fixed Nobuyuki goal: "Achika's memory" â†’ "Kiyone's memory" (OVA canon mother)
 * - Fixed Tenchi ghost: Clarified mother is Kiyone Masaki
 * - Added Kiyone Masaki (deceased) as tracked character
 * - Added Tennyo Masaki as character
 * - Added Juraian (Unbonded) species for non-tree-bonded Juraians
 * - Added canonical locks for Yosho birth and Kiyone death
 * - Added family relationship facts
 * - Corrected comment on line 38 (Yosho age consistency)
 * 
 * Populates the database with canonical data:
 * - Species (Human, Juraian Royal, Juraian Unbonded, Juraian-Human Hybrid)
 * - Core characters with birth dates and aging curves
 * - Canonical timeline locks
 * - Forbidden word rules
 * - Initial tracked facts
 * - Family relationships
 * 
 * Run: npx tsx src/scripts/seed-son-of-cosmos.ts
 */

import { EpicFictionArchitect, CANONICAL_LOCKS, SHELDON_FORBIDDEN_WORDS } from '../index';
import type { AgingCurvePoint, TrackedFact } from '../core/types';

// ============================================================================
// CANONICAL LOCKS (Extended)
// ============================================================================

/**
 * Extended canonical locks including corrections from OVA canon verification
 */
const EXTENDED_LOCKS = {
  ...CANONICAL_LOCKS,
  // Yosho born ~1262 CE (730 years old in early 1990s per OVA 1)
  YOSHO_BIRTH: { year: 1262, month: 3, day: 15 },
  // Nobuyuki born 19th century per OVA canon
  NOBUYUKI_BIRTH: { year: 1869, month: 6, day: 12 },
  // Kiyone Masaki died ~1986-1987, age 248 (no bio-enhancement)
  KIYONE_MASAKI_BIRTH: { year: 1739, month: 9, day: 3 },
  KIYONE_MASAKI_DEATH: { year: 1987, month: 2, day: 14 },
  // Tennyo born ~1910
  TENNYO_BIRTH: { year: 1910, month: 7, day: 22 },
  // Ryoko sealed ~1287 CE (700 years before release)
  RYOKO_SEALED: { year: 1287, month: 8, day: 1 },
};

// ============================================================================
// AGING CURVES
// ============================================================================

/**
 * Human aging curve (1:1 chronological to biological)
 * Max lifespan ~100 years without enhancement
 */
const HUMAN_AGING: AgingCurvePoint[] = [
  { chronologicalAge: 0, apparentAge: 0, label: 'infant' },
  { chronologicalAge: 5, apparentAge: 5, label: 'child' },
  { chronologicalAge: 13, apparentAge: 13, label: 'adolescent' },
  { chronologicalAge: 18, apparentAge: 18, label: 'young adult' },
  { chronologicalAge: 30, apparentAge: 30, label: 'adult' },
  { chronologicalAge: 50, apparentAge: 50, label: 'middle-aged' },
  { chronologicalAge: 70, apparentAge: 70, label: 'elder' },
  { chronologicalAge: 100, apparentAge: 100, label: 'ancient' }
];

/**
 * Juraian Royal aging curve (bonded to Royal Trees)
 * Based on OVA canon: Juraians bonded to Royal Trees age extremely slowly
 * - Yosho is ~730 years old but appears ~30 (true form) or ~80 (disguise)
 * - Ayeka is 721+ years old but appears 17-18 (700 years in stasis)
 * - Sasami is 708+ years old but appears 8-9 (700 years in stasis)
 */
const JURAIAN_ROYAL_AGING: AgingCurvePoint[] = [
  { chronologicalAge: 0, apparentAge: 0, label: 'infant' },
  { chronologicalAge: 50, apparentAge: 5, label: 'child' },
  { chronologicalAge: 150, apparentAge: 10, label: 'child' },
  { chronologicalAge: 300, apparentAge: 15, label: 'adolescent' },
  { chronologicalAge: 500, apparentAge: 18, label: 'young adult' },
  { chronologicalAge: 730, apparentAge: 30, label: 'adult' }, // Yosho's current state
  { chronologicalAge: 1000, apparentAge: 32, label: 'adult' },
  { chronologicalAge: 2000, apparentAge: 35, label: 'mature' },
  { chronologicalAge: 5000, apparentAge: 50, label: 'middle-aged' },
  { chronologicalAge: 10000, apparentAge: 65, label: 'elder' }
];

/**
 * Juraian Unbonded aging curve (no Royal Tree bond, no bio-enhancement)
 * Based on OVA canon: Kiyone Masaki lived to 248 without bio-enhancement
 * Slower than human but not immortal
 */
const JURAIAN_UNBONDED_AGING: AgingCurvePoint[] = [
  { chronologicalAge: 0, apparentAge: 0, label: 'infant' },
  { chronologicalAge: 10, apparentAge: 5, label: 'child' },
  { chronologicalAge: 25, apparentAge: 13, label: 'adolescent' },
  { chronologicalAge: 40, apparentAge: 18, label: 'young adult' },
  { chronologicalAge: 80, apparentAge: 30, label: 'adult' },
  { chronologicalAge: 150, apparentAge: 50, label: 'middle-aged' },
  { chronologicalAge: 200, apparentAge: 65, label: 'elder' },
  { chronologicalAge: 248, apparentAge: 80, label: 'ancient' } // Kiyone's death age
];

/**
 * Juraian-Human Hybrid aging curve
 * Based on OVA canon:
 * - Tennyo is 80+ but appears young (has Juraian heritage)
 * - Nobuyuki was born ~1869 (120+ years old in 1989)
 * - Tenchi ages normally pre-bonding, then slows dramatically
 * Hybrids inherit partial longevity even without Tree bonding
 */
const JURAIAN_HUMAN_HYBRID_AGING: AgingCurvePoint[] = [
  { chronologicalAge: 0, apparentAge: 0, label: 'infant' },
  { chronologicalAge: 5, apparentAge: 5, label: 'child' },
  { chronologicalAge: 13, apparentAge: 13, label: 'adolescent' },
  { chronologicalAge: 18, apparentAge: 18, label: 'young adult' },
  { chronologicalAge: 30, apparentAge: 22, label: 'adult' },
  { chronologicalAge: 50, apparentAge: 28, label: 'adult' },
  { chronologicalAge: 80, apparentAge: 35, label: 'mature' }, // Tennyo's range
  { chronologicalAge: 120, apparentAge: 40, label: 'mature' }, // Nobuyuki's range
  { chronologicalAge: 200, apparentAge: 50, label: 'middle-aged' },
  { chronologicalAge: 500, apparentAge: 60, label: 'elder' },
  { chronologicalAge: 1000, apparentAge: 70, label: 'ancient' }
];

// ============================================================================
// MAIN SEEDING FUNCTION
// ============================================================================

async function seedDatabase() {
  console.log('ðŸŒ± Starting Son of Cosmos database seeding (CORRECTED)...\n');

  // Initialize application
  const app = new EpicFictionArchitect({
    databasePath: './son_of_cosmos.db'
  });

  try {
    // ========================================================================
    // CREATE PROJECT
    // ========================================================================
    console.log('ðŸ“š Creating project...');
    
    const project = app.createProject('Son of Cosmos: JumpChain', {
      description: `A 300-million-word fanfiction crossover combining Sailor Moon and Tenchi Muyo! universes. 
The story follows Sheldon Carter, a theoretical physicist who dies in a 2025 lab accident and is 
resurrected by Sailor Cosmos as her first son, placed in 1989 Japan when Tenchi is 4 years old.

CANON BASIS: Tenchi Muyo! Ryo-Ohki OVA continuity (NOT Tenchi Universe).
- Tenchi's mother is Kiyone Masaki (NOT Achika)
- Kiyone Makibi does NOT exist in OVA canon
- Yosho is ~730 years old, born ~1262 CE
- Nobuyuki was born in the 19th century (~1869)`,
      genre: 'Science Fantasy / Slice of Life / Found Family',
      targetWordCount: 300000000,
      settings: {
        wordsPerPage: 250,
        targetDailyWords: 2000,
        forbiddenWords: SHELDON_FORBIDDEN_WORDS
      }
    });

    console.log(`   âœ“ Project created: ${project.id}\n`);

    // ========================================================================
    // CREATE SPECIES
    // ========================================================================
    console.log('ðŸ§¬ Creating species...');

    const humanSpecies = app.createSpecies('Human', HUMAN_AGING, {
      description: 'Baseline humans from Earth. No Juraian heritage.',
      averageLifespan: 80,
      maxLifespan: 100,
      maturityAge: 18,
      elderAge: 65
    });
    console.log(`   âœ“ Human species: ${humanSpecies.id}`);

    const juraianRoyalSpecies = app.createSpecies('Juraian Royal', JURAIAN_ROYAL_AGING, {
      description: 'Juraian royalty bonded to first-generation Royal Trees. Effectively immortal while within range of their Tree. Power flows from Tsunami-no-ki through subspace network.',
      averageLifespan: undefined, // Immortal with Tree
      maxLifespan: undefined,
      maturityAge: 500,
      elderAge: 5000,
      notes: 'Must remain within range of bonded Tree for immortality. Yosho cannot leave Earth because Funaho is rooted at the shrine.'
    });
    console.log(`   âœ“ Juraian Royal species: ${juraianRoyalSpecies.id}`);

    const juraianUnbondedSpecies = app.createSpecies('Juraian (Unbonded)', JURAIAN_UNBONDED_AGING, {
      description: 'Juraians without Royal Tree bonds or bio-enhancement. Extended lifespan (~250 years) but not immortal. Kiyone Masaki was this type.',
      averageLifespan: 200,
      maxLifespan: 250,
      maturityAge: 40,
      elderAge: 150,
      notes: 'Kiyone Masaki lived to 248 without bio-enhancement, suffering senility in final years.'
    });
    console.log(`   âœ“ Juraian Unbonded species: ${juraianUnbondedSpecies.id}`);

    const hybridSpecies = app.createSpecies('Juraian-Human Hybrid', JURAIAN_HUMAN_HYBRID_AGING, {
      description: 'Children of Juraian and Human parents. Inherit partial longevity even without Tree bonding. Age normally in childhood, then slow dramatically.',
      averageLifespan: 300,
      maxLifespan: undefined, // Can bond to Tree
      maturityAge: 18,
      elderAge: 200,
      notes: 'Tennyo (80+) appears young. Nobuyuki (~120 in 1989) appears middle-aged. Tenchi has no theoretical limit due to godlike powers.'
    });
    console.log(`   âœ“ Hybrid species: ${hybridSpecies.id}\n`);

    // ========================================================================
    // CREATE CHARACTERS
    // ========================================================================
    console.log('ðŸ‘¤ Creating characters...');

    // ------------------------------------------------------------------------
    // Sheldon Carter - Protagonist
    // ------------------------------------------------------------------------
    const sheldon = app.createCharacter('Sheldon Carter', {
      fullName: 'Sheldon Marcus Carter',
      aliases: ['Shel', 'the new teacher', 'Carter-san'],
      nicknames: ['Shel-kun'],
      role: 'protagonist',
      arcType: 'positive_change',
      speciesId: humanSpecies.id,
      gender: 'male',
      pronouns: 'he/him',
      birthDate: { 
        year: EXTENDED_LOCKS.SHELDON_BIRTH.year, 
        month: EXTENDED_LOCKS.SHELDON_BIRTH.month, 
        day: EXTENDED_LOCKS.SHELDON_BIRTH.day 
      },
      birthPlace: 'Griffin, Georgia, USA',
      deathDate: { 
        year: EXTENDED_LOCKS.SHELDON_DEATH.year, 
        month: EXTENDED_LOCKS.SHELDON_DEATH.month, 
        day: EXTENDED_LOCKS.SHELDON_DEATH.day 
      },
      deathPlace: 'University of Alaska Fairbanks',
      deathCause: 'Laboratory accident (theoretical physics experiment)',
      physicalDescription: {
        height: '5\'10"',
        build: 'lean',
        hairColor: 'brown',
        eyeColor: 'hazel',
        skinTone: 'fair',
        distinguishingFeatures: [
          'slight Southern accent (fading)',
          'tends to gesture when explaining',
          'perpetually slightly disheveled'
        ]
      },
      psychology: {
        lie: 'I need to earn my place here through achievement',
        truth: 'Belonging comes from connection, not accomplishment',
        want: 'To understand his new existence and build a meaningful life',
        need: 'To accept love without feeling he must prove his worth',
        ghost: 'Death at 37 in lab accident; decades of academic isolation; never felt he belonged anywhere',
        wound: 'Emotional distance from family; career prioritized over relationships',
        traits: ['analytical', 'curious', 'protective', 'guarded', 'patient', 'observant'],
        fears: [
          'failing to protect those he cares about',
          'being truly known and rejected',
          'his second chance being taken away'
        ],
        goals: [
          'understand his abilities',
          'build genuine family bonds',
          'protect Tenchi and the household'
        ],
        strengths: [
          'intellectual curiosity',
          'patience with children',
          'cooking (Supreme Chef ability)',
          'teaching'
        ],
        weaknesses: [
          'difficulty accepting help',
          'tendency to overthink',
          'emotional guardedness'
        ]
      },
      voiceFingerprint: {
        vocabularyComplexity: 'complex',
        favoredWords: ['interesting', 'consider', 'perhaps'],
        avoidedWords: [], // Forbidden words handled separately
        catchphrases: [],
        averageSentenceLength: 18,
        sentenceVariation: 'high',
        preferredStructures: ['complex', 'compound-complex'],
        formalityLevel: 65,
        emotionalExpressiveness: 40,
        humorStyle: 'dry',
        dialect: 'Southern American (fading)',
        languageTics: ['pausing before important points', 'rhetorical questions when teaching'],
        sampleDialogue: [],
        sampleInternalMonologue: []
      }
    });
    console.log(`   âœ“ Sheldon Carter: ${sheldon.id}`);

    // ------------------------------------------------------------------------
    // Tenchi Masaki - Deuteragonist
    // ------------------------------------------------------------------------
    const tenchi = app.createCharacter('Tenchi Masaki', {
      fullName: 'Tenchi Masaki',
      aliases: ['Ten-chan'],
      nicknames: ['Ten-chan'],
      role: 'deuteragonist',
      arcType: 'coming_of_age',
      speciesId: hybridSpecies.id,
      gender: 'male',
      pronouns: 'he/him',
      birthDate: { 
        year: EXTENDED_LOCKS.TENCHI_BIRTH.year, 
        month: EXTENDED_LOCKS.TENCHI_BIRTH.month, 
        day: EXTENDED_LOCKS.TENCHI_BIRTH.day 
      },
      birthPlace: 'Kurashiki, Okayama Prefecture, Japan',
      physicalDescription: {
        height: '4\'0" (age 5)',
        build: 'child',
        hairColor: 'black',
        eyeColor: 'brown',
        distinguishingFeatures: ['will grow into handsome young man', 'inherited mother\'s gentle eyes']
      },
      psychology: {
        lie: 'I\'m just an ordinary kid',
        truth: 'My heritage gives me responsibilities I\'ll grow into',
        want: 'To play and have fun like a normal child',
        need: 'A stable family structure during formative years',
        ghost: 'Mother Kiyone Masaki died when he was ~2-3 years old (too young to remember clearly)',
        traits: ['energetic', 'curious', 'kind', 'stubborn when tired', 'brave'],
        fears: ['being alone', 'disappointing grandfather', 'the dark (age 5)'],
        goals: ['learn sword fighting', 'explore the shrine grounds', 'make Grandpa proud']
      },
      family: {
        mother: 'Kiyone Masaki (deceased)',
        father: 'Nobuyuki Masaki',
        grandfather: 'Yosho Masaki Jurai (Katsuhito)',
        grandmother: 'Airi Masaki (paternal, living off-world)',
        sister: 'Tennyo Masaki (older)',
        adoptedSister: 'Rea Masaki'
      },
      canonNotes: 'In OVA canon, Tenchi\'s mother is Kiyone Masaki (NOT Achika from Tenchi Universe). He is Kami Tenchiâ€”the entity the Chousin sought, surpassing even them in power.'
    });
    console.log(`   âœ“ Tenchi Masaki: ${tenchi.id}`);

    // ------------------------------------------------------------------------
    // Yosho/Katsuhito - Mentor
    // CORRECTED: Birth year ~1262 CE (730 years old per OVA 1)
    // ------------------------------------------------------------------------
    const yosho = app.createCharacter('Yosho Masaki Jurai', {
      fullName: 'Yosho Masaki Jurai',
      aliases: ['Katsuhito Masaki', 'Grandpa', 'old man', 'Crown Prince Yosho'],
      nicknames: ['Grandpa', 'Jii-chan', 'Katsuhito'],
      role: 'mentor',
      arcType: 'flat_testing',
      speciesId: juraianRoyalSpecies.id,
      gender: 'male',
      pronouns: 'he/him',
      birthDate: { 
        year: EXTENDED_LOCKS.YOSHO_BIRTH.year, 
        month: EXTENDED_LOCKS.YOSHO_BIRTH.month, 
        day: EXTENDED_LOCKS.YOSHO_BIRTH.day 
      },
      birthPlace: 'Jurai Royal Palace',
      physicalDescription: {
        height: '5\'8"',
        build: 'deceptively frail (disguise); actually fit and powerful (true form)',
        hairColor: 'gray (disguise); dark (true form)',
        eyeColor: 'brown',
        apparentAge: '80-90 (disguise barrier illusion)',
        trueAge: '~30 (actual appearance)',
        distinguishingFeatures: [
          'elderly appearance is illusion barrier to avoid suspicion',
          'true form appears around 30 years old',
          'moves with hidden grace when unobserved'
        ]
      },
      psychology: {
        lie: 'I must carry this burden alone',
        truth: 'Sharing responsibility strengthens everyone',
        want: 'To protect Earth from Juraian discovery',
        need: 'To let others share his mission; to find companionship after centuries of isolation',
        ghost: 'Mother Funaho\'s sacrifice; self-exile from Jurai; sealing Ryoko after her rampage; daughter Kiyone\'s death; centuries of solitude',
        wound: '700+ years of isolation on Earth, watching loved ones age and die',
        traits: ['wise', 'patient', 'cryptic', 'secretly playful', 'protective', 'lonely'],
        fears: ['Jurai finding Earth', 'failing to prepare Tenchi', 'outliving everyone he loves again'],
        goals: ['train Tenchi for what\'s coming', 'maintain shrine and Funaho tree', 'watch over sealed Ryoko', 'protect Earth']
      },
      family: {
        father: 'Emperor Azusa Masaki Jurai',
        mother: 'Empress Funaho (First Wife, Earth-born)',
        halfSisters: ['Ayeka Masaki Jurai', 'Sasami Masaki Jurai'],
        firstWife: 'Kasumi (Funaho\'s niece, deceased)',
        currentWife: 'Airi Masaki (common-law, never formally married)',
        daughter: 'Kiyone Masaki (deceased)',
        granddaughter: 'Tennyo Masaki',
        grandson: 'Tenchi Masaki',
        descendant: 'Nobuyuki Masaki (through Kasumi line)'
      },
      royalTree: 'Funaho (first-generation, rooted at Masaki Shrineâ€”cannot take ship form)',
      canonNotes: 'Crown Prince of Jurai who fled after defeating Ryoko. Cannot leave Earth because Funaho is rooted. The three gems on Tenchi-ken powered Funaho for 700 years. Verified at 730 years old in OVA 1.'
    });
    console.log(`   âœ“ Yosho/Katsuhito: ${yosho.id}`);

    // ------------------------------------------------------------------------
    // Nobuyuki Masaki
    // CORRECTED: Birth year ~1869 (19th century per OVA canon)
    // CORRECTED: Species is Hybrid (lives 120+ years)
    // CORRECTED: Wife is Kiyone (NOT Achika)
    // ------------------------------------------------------------------------
    const nobuyuki = app.createCharacter('Nobuyuki Masaki', {
      fullName: 'Nobuyuki Masaki',
      aliases: ['Nobu', 'Tenchi\'s father'],
      role: 'ally',
      speciesId: hybridSpecies.id, // CORRECTED: Was humanSpecies
      gender: 'male',
      pronouns: 'he/him',
      birthDate: { 
        year: EXTENDED_LOCKS.NOBUYUKI_BIRTH.year, 
        month: EXTENDED_LOCKS.NOBUYUKI_BIRTH.month, 
        day: EXTENDED_LOCKS.NOBUYUKI_BIRTH.day 
      },
      birthPlace: 'Masaki Village, Okayama Prefecture, Japan',
      physicalDescription: {
        height: '5\'9"',
        build: 'average',
        hairColor: 'black',
        eyeColor: 'brown',
        apparentAge: '~40 (actual age ~120 in 1989)',
        distinguishingFeatures: ['looks middle-aged despite being 120+ years old', 'architect\'s hands']
      },
      psychology: {
        lie: 'I can manage being both working father and present parent',
        truth: 'Tenchi needs more than weekend visits',
        want: 'To provide for Tenchi financially and honor his wife\'s memory',
        need: 'To be more present in Tenchi\'s life',
        ghost: 'Wife Kiyone\'s death after 80+ years of marriage; guilt over working in Kurashiki instead of living at shrine',
        traits: ['hardworking', 'devoted father', 'sometimes awkward', 'caring', 'skilled architect'],
        fears: ['failing as a single parent', 'Tenchi forgetting Kiyone', 'not being there when needed'],
        goals: [
          'raise Tenchi well',
          'honor Kiyone\'s memory', // CORRECTED: Was "Achika's memory"
          'balance work and family'
        ]
      },
      family: {
        wife: 'Kiyone Masaki (deceased)',
        son: 'Tenchi Masaki',
        daughter: 'Tennyo Masaki',
        adoptedDaughter: 'Rea Masaki',
        fatherInLaw: 'Yosho Masaki Jurai (Katsuhito)',
        ancestor: 'Kasumi (Yosho\'s first wife)'
      },
      occupation: 'Architect in Kurashiki',
      canonNotes: 'Descendant of Yosho through Kasumi line. Born 19th century per OVA canon. Wife was Kiyone Masaki (NOT Achikaâ€”Achika is Tenchi Universe only). Kiyone tormented him for decades before finally marrying him.'
    });
    console.log(`   âœ“ Nobuyuki Masaki: ${nobuyuki.id}`);

    // ------------------------------------------------------------------------
    // Kiyone Masaki - Tenchi's Mother (Deceased)
    // NEW CHARACTER - Critical for canon accuracy
    // ------------------------------------------------------------------------
    const kiyoneMasaki = app.createCharacter('Kiyone Masaki', {
      fullName: 'Kiyone Masaki',
      aliases: ['Tenchi\'s mother'],
      role: 'background', // Deceased before story start
      arcType: 'tragic',
      speciesId: juraianUnbondedSpecies.id,
      gender: 'female',
      pronouns: 'she/her',
      status: 'dead',
      birthDate: {
        year: EXTENDED_LOCKS.KIYONE_MASAKI_BIRTH.year,
        month: EXTENDED_LOCKS.KIYONE_MASAKI_BIRTH.month,
        day: EXTENDED_LOCKS.KIYONE_MASAKI_BIRTH.day
      },
      birthPlace: 'Unknown (daughter of Yosho and Airi)',
      deathDate: {
        year: EXTENDED_LOCKS.KIYONE_MASAKI_DEATH.year,
        month: EXTENDED_LOCKS.KIYONE_MASAKI_DEATH.month,
        day: EXTENDED_LOCKS.KIYONE_MASAKI_DEATH.day
      },
      deathCause: 'Natural aging (no bio-enhancement), suffered senility in final years',
      deathAge: 248,
      physicalDescription: {
        height: '5\'4"',
        build: 'slender',
        hairColor: 'dark',
        eyeColor: 'brown',
        distinguishingFeatures: ['Tennyo is her exact physical double']
      },
      psychology: {
        traits: ['patient', 'loving', 'mischievous', 'devoted mother'],
        ghost: 'Tormented Nobuyuki for decades before finally accepting his devotion'
      },
      family: {
        father: 'Yosho Masaki Jurai',
        mother: 'Airi Masaki',
        husband: 'Nobuyuki Masaki',
        daughter: 'Tennyo Masaki',
        son: 'Tenchi Masaki',
        adoptedDaughter: 'Rea Masaki',
        sibling: 'Minaho'
      },
      canonNotes: 'NOT the same as Kiyone Makibi (Galaxy Police partner of Mihoshi who does NOT exist in OVA canon). Lived to 248 without bio-enhancement. Tenchi was ~2-3 when she died.'
    });
    console.log(`   âœ“ Kiyone Masaki (deceased): ${kiyoneMasaki.id}`);

    // ------------------------------------------------------------------------
    // Tennyo Masaki - Tenchi's Older Sister
    // NEW CHARACTER - Present in OVA 3
    // ------------------------------------------------------------------------
    const tennyo = app.createCharacter('Tennyo Masaki', {
      fullName: 'Tennyo Masaki',
      aliases: ['Tenchi\'s sister'],
      role: 'ally',
      speciesId: hybridSpecies.id,
      gender: 'female',
      pronouns: 'she/her',
      birthDate: {
        year: EXTENDED_LOCKS.TENNYO_BIRTH.year,
        month: EXTENDED_LOCKS.TENNYO_BIRTH.month,
        day: EXTENDED_LOCKS.TENNYO_BIRTH.day
      },
      physicalDescription: {
        height: '5\'4"',
        build: 'slender',
        hairColor: 'dark',
        eyeColor: 'brown',
        apparentAge: '~20s (actual age 79 in 1989)',
        distinguishingFeatures: ['exact physical double of her mother Kiyone']
      },
      psychology: {
        traits: ['caring older sister', 'responsible', 'protective'],
        goals: ['watch over younger brother Tenchi', 'honor mother\'s memory']
      },
      family: {
        mother: 'Kiyone Masaki (deceased)',
        father: 'Nobuyuki Masaki',
        brother: 'Tenchi Masaki',
        grandfather: 'Yosho Masaki Jurai',
        grandmother: 'Airi Masaki'
      },
      canonNotes: 'Introduced in OVA 3. Over 80 years old but appears young due to Juraian heritage. Exact physical double of her mother.'
    });
    console.log(`   âœ“ Tennyo Masaki: ${tennyo.id}\n`);

    // ========================================================================
    // CREATE CANONICAL FACTS
    // ========================================================================
    console.log('ðŸ“‹ Creating canonical facts...');

    // Tenchi's birth date (LOCKED)
    app.trackFact({
      category: 'character_attribute',
      subjectType: 'character',
      subjectId: tenchi.id,
      attribute: 'birth_date',
      value: EXTENDED_LOCKS.TENCHI_BIRTH,
      valueType: 'object',
      source: { type: 'canonical', name: 'OVA Canon' },
      establishedAt: 0,
      isCanonical: true,
      isLocked: true,
      tags: ['canonical-lock', 'birthday', 'tenchi'],
      confidence: 1.0
    });
    console.log('   âœ“ Tenchi birth date: April 24, 1984 (LOCKED)');

    // Yosho's birth date (LOCKED) - CORRECTED
    app.trackFact({
      category: 'character_attribute',
      subjectType: 'character',
      subjectId: yosho.id,
      attribute: 'birth_date',
      value: EXTENDED_LOCKS.YOSHO_BIRTH,
      valueType: 'object',
      source: { type: 'canonical', name: 'OVA Canon - 730 years old in OVA 1' },
      establishedAt: 0,
      isCanonical: true,
      isLocked: true,
      tags: ['canonical-lock', 'birthday', 'yosho'],
      confidence: 1.0
    });
    console.log('   âœ“ Yosho birth date: ~1262 CE (LOCKED)');

    // Nobuyuki's birth date (LOCKED) - CORRECTED
    app.trackFact({
      category: 'character_attribute',
      subjectType: 'character',
      subjectId: nobuyuki.id,
      attribute: 'birth_date',
      value: EXTENDED_LOCKS.NOBUYUKI_BIRTH,
      valueType: 'object',
      source: { type: 'canonical', name: 'OVA Canon - born 19th century' },
      establishedAt: 0,
      isCanonical: true,
      isLocked: true,
      tags: ['canonical-lock', 'birthday', 'nobuyuki'],
      confidence: 1.0
    });
    console.log('   âœ“ Nobuyuki birth date: ~1869 (LOCKED)');

    // Kiyone Masaki death (LOCKED)
    app.trackFact({
      category: 'character_state',
      subjectType: 'character',
      subjectId: kiyoneMasaki.id,
      attribute: 'death_date',
      value: EXTENDED_LOCKS.KIYONE_MASAKI_DEATH,
      valueType: 'object',
      source: { type: 'canonical', name: 'OVA Canon - died age 248' },
      establishedAt: 0,
      isCanonical: true,
      isLocked: true,
      tags: ['canonical-lock', 'death', 'kiyone-masaki'],
      confidence: 1.0
    });
    console.log('   âœ“ Kiyone Masaki death: ~1986-1987, age 248 (LOCKED)');

    // Masaki Shrine step count (LOCKED)
    app.trackFact({
      category: 'location',
      subjectType: 'location',
      subjectId: 'masaki-shrine',
      attribute: 'step_count',
      value: EXTENDED_LOCKS.MASAKI_SHRINE_STEPS,
      valueType: 'number',
      source: { type: 'canonical', name: 'Tarojinja Research' },
      establishedAt: 0,
      isCanonical: true,
      isLocked: true,
      tags: ['canonical-lock', 'location', 'shrine'],
      confidence: 1.0
    });
    console.log('   âœ“ Masaki Shrine steps: 320 (LOCKED)');

    // Ryoko release date (LOCKED)
    app.trackFact({
      category: 'timeline',
      subjectType: 'character',
      subjectId: 'ryoko',
      attribute: 'release_date',
      value: EXTENDED_LOCKS.RYOKO_RELEASE,
      valueType: 'object',
      source: { type: 'canonical', name: 'OVA Canon - Obon 2001' },
      establishedAt: 0,
      isCanonical: true,
      isLocked: true,
      tags: ['canonical-lock', 'timeline', 'ryoko', 'obon'],
      confidence: 1.0
    });
    console.log('   âœ“ Ryoko release date: August 13, 2001 (LOCKED)');

    // Story start date
    app.trackFact({
      category: 'timeline',
      subjectType: 'world',
      subjectId: 'story',
      attribute: 'start_date',
      value: EXTENDED_LOCKS.STORY_START,
      valueType: 'object',
      source: { type: 'canonical', name: 'Story Bible' },
      establishedAt: 0,
      isCanonical: true,
      isLocked: true,
      tags: ['canonical-lock', 'timeline', 'chapter-1'],
      confidence: 1.0
    });
    console.log('   âœ“ Story start: April 3, 1989 (LOCKED)');

    // Sheldon's residence (temporal)
    app.trackFact({
      category: 'character_state',
      subjectType: 'character',
      subjectId: sheldon.id,
      attribute: 'residence',
      value: 'shrine_guest_room',
      valueType: 'string',
      source: { type: 'scene', name: 'Chapter 1, Day 1' },
      establishedAt: 19890403,
      validUntil: 19890419, // Days 1-17
      isCanonical: true,
      isLocked: false,
      tags: ['residence', 'timeline', 'sheldon'],
      confidence: 1.0
    });
    console.log('   âœ“ Sheldon residence: shrine guest room (Days 1-17)');

    app.trackFact({
      category: 'character_state',
      subjectType: 'character',
      subjectId: sheldon.id,
      attribute: 'residence',
      value: 'tsukino_house',
      valueType: 'string',
      source: { type: 'scene', name: 'Chapter 1, Day 18' },
      establishedAt: 19890420,
      isCanonical: true,
      isLocked: false,
      tags: ['residence', 'timeline', 'sheldon'],
      confidence: 1.0
    });
    console.log('   âœ“ Sheldon residence: Tsukino house (Day 18+)');

    // Tenchi's age at story start
    const tenchiAge = app.calculateAge(tenchi.id, EXTENDED_LOCKS.STORY_START);
    if (tenchiAge) {
      app.trackFact({
        category: 'character_attribute',
        subjectType: 'character',
        subjectId: tenchi.id,
        attribute: 'age_at_story_start',
        value: { chronological: tenchiAge.chronological, apparent: tenchiAge.apparent },
        valueType: 'object',
        source: { type: 'canonical', name: 'Calculated' },
        establishedAt: 19890403,
        isCanonical: true,
        isLocked: true,
        tags: ['age', 'tenchi', 'story-start'],
        confidence: 1.0
      });
      console.log(`   âœ“ Tenchi age at story start: ${tenchiAge.chronological} (LOCKED)`);
    }

    // Day 22 birthday (Tenchi turns 5)
    app.trackFact({
      category: 'timeline',
      subjectType: 'character',
      subjectId: tenchi.id,
      attribute: 'birthday_chapter_1',
      value: { year: 1989, month: 4, day: 24, event: 'Tenchi turns 5' },
      valueType: 'object',
      source: { type: 'canonical', name: 'Story Bible' },
      establishedAt: 19890424,
      isCanonical: true,
      isLocked: true,
      tags: ['birthday', 'tenchi', 'day-22', 'chapter-1'],
      confidence: 1.0
    });
    console.log('   âœ“ Tenchi birthday: Day 22 (April 24, 1989) (LOCKED)');

    // Yosho's age at story start
    const yoshoAge = app.calculateAge(yosho.id, EXTENDED_LOCKS.STORY_START);
    if (yoshoAge) {
      app.trackFact({
        category: 'character_attribute',
        subjectType: 'character',
        subjectId: yosho.id,
        attribute: 'age_at_story_start',
        value: { chronological: yoshoAge.chronological, apparent: yoshoAge.apparent },
        valueType: 'object',
        source: { type: 'canonical', name: 'Calculated from 1262 CE birth' },
        establishedAt: 19890403,
        isCanonical: true,
        isLocked: true,
        tags: ['age', 'yosho', 'story-start'],
        confidence: 1.0
      });
      console.log(`   âœ“ Yosho age at story start: ${yoshoAge.chronological} (~727 years) (LOCKED)`);
    }

    // Nobuyuki's age at story start
    const nobuyukiAge = app.calculateAge(nobuyuki.id, EXTENDED_LOCKS.STORY_START);
    if (nobuyukiAge) {
      app.trackFact({
        category: 'character_attribute',
        subjectType: 'character',
        subjectId: nobuyuki.id,
        attribute: 'age_at_story_start',
        value: { chronological: nobuyukiAge.chronological, apparent: nobuyukiAge.apparent },
        valueType: 'object',
        source: { type: 'canonical', name: 'Calculated from 1869 birth' },
        establishedAt: 19890403,
        isCanonical: true,
        isLocked: true,
        tags: ['age', 'nobuyuki', 'story-start'],
        confidence: 1.0
      });
      console.log(`   âœ“ Nobuyuki age at story start: ${nobuyukiAge.chronological} (~120 years) (LOCKED)`);
    }
    console.log('');

    // ========================================================================
    // CREATE FAMILY RELATIONSHIPS
    // ========================================================================
    console.log('ðŸ‘¨â€ðŸ‘©â€ðŸ‘§â€ðŸ‘¦ Creating family relationships...');

    // Tenchi's immediate family
    app.trackFact({
      category: 'relationship',
      subjectType: 'character',
      subjectId: tenchi.id,
      attribute: 'mother',
      value: { characterId: kiyoneMasaki.id, name: 'Kiyone Masaki', status: 'deceased' },
      valueType: 'object',
      source: { type: 'canonical', name: 'OVA Canon' },
      establishedAt: 0,
      isCanonical: true,
      isLocked: true,
      tags: ['family', 'tenchi', 'kiyone-masaki'],
      confidence: 1.0
    });
    console.log('   âœ“ Tenchi â†’ Kiyone Masaki (mother, deceased)');

    app.trackFact({
      category: 'relationship',
      subjectType: 'character',
      subjectId: tenchi.id,
      attribute: 'father',
      value: { characterId: nobuyuki.id, name: 'Nobuyuki Masaki' },
      valueType: 'object',
      source: { type: 'canonical', name: 'OVA Canon' },
      establishedAt: 0,
      isCanonical: true,
      isLocked: true,
      tags: ['family', 'tenchi', 'nobuyuki'],
      confidence: 1.0
    });
    console.log('   âœ“ Tenchi â†’ Nobuyuki Masaki (father)');

    app.trackFact({
      category: 'relationship',
      subjectType: 'character',
      subjectId: tenchi.id,
      attribute: 'grandfather',
      value: { characterId: yosho.id, name: 'Yosho Masaki Jurai (Katsuhito)' },
      valueType: 'object',
      source: { type: 'canonical', name: 'OVA Canon' },
      establishedAt: 0,
      isCanonical: true,
      isLocked: true,
      tags: ['family', 'tenchi', 'yosho'],
      confidence: 1.0
    });
    console.log('   âœ“ Tenchi â†’ Yosho/Katsuhito (grandfather)');

    app.trackFact({
      category: 'relationship',
      subjectType: 'character',
      subjectId: tenchi.id,
      attribute: 'sister',
      value: { characterId: tennyo.id, name: 'Tennyo Masaki' },
      valueType: 'object',
      source: { type: 'canonical', name: 'OVA Canon' },
      establishedAt: 0,
      isCanonical: true,
      isLocked: true,
      tags: ['family', 'tenchi', 'tennyo'],
      confidence: 1.0
    });
    console.log('   âœ“ Tenchi â†’ Tennyo Masaki (older sister)');

    // Canon clarification fact
    app.trackFact({
      category: 'canon_note',
      subjectType: 'world',
      subjectId: 'ova-canon',
      attribute: 'mother_clarification',
      value: 'Tenchi\'s mother in OVA canon is KIYONE MASAKI, not Achika. Achika appears only in Tenchi Universe continuity and the film "Tenchi Muyo! in Love." Kiyone Makibi (Mihoshi\'s partner) does NOT exist in OVA canon.',
      valueType: 'string',
      source: { type: 'canonical', name: 'OVA Canon Verification' },
      establishedAt: 0,
      isCanonical: true,
      isLocked: true,
      tags: ['canon-note', 'critical', 'mother', 'kiyone'],
      confidence: 1.0
    });
    console.log('   âœ“ Canon clarification: Kiyone Masaki is Tenchi\'s mother (NOT Achika)\n');

    // ========================================================================
    // CREATE CHAPTER 1 STRUCTURE
    // ========================================================================
    console.log('ðŸ“– Creating Chapter 1 structure...');

    const book1 = app.createContainer('book', 'Book 1: First Son', {
      synopsis: 'The story of Sheldon Carter\'s arrival and first years at Masaki Shrine. Covers 1989-1993 (Years 1-4), culminating in Sheldon\'s revelation to Yosho and the beginning of early training.',
      targetWordCount: 10000000
    });
    console.log(`   âœ“ Book 1: ${book1.id}`);

    const chapter1 = app.createContainer('chapter', 'Chapter 1: Arrival', {
      parentId: book1.id,
      synopsis: 'Days 1-29 (April 3-30, 1989). Sheldon arrives at Masaki Shrine and begins building connections. Tenchi turns 5 on Day 22.',
      targetWordCount: 500000,
      timeline: 'April 3-30, 1989'
    });
    console.log(`   âœ“ Chapter 1: ${chapter1.id}`);

    // Create Day 1 placeholder scene
    const day1Scene = app.createScene(chapter1.id, 'Day 1 - Arrival', {
      synopsis: 'Sheldon awakens at Masaki Shrine. First meeting with Yosho/Katsuhito.',
      date: { year: 1989, month: 4, day: 3 },
      povCharacterId: sheldon.id,
      characterIds: [sheldon.id, yosho.id],
      status: 'outline'
    });
    console.log(`   âœ“ Day 1 scene: ${day1Scene.id}\n`);

    // ========================================================================
    // CREATE CONSISTENCY RULES
    // ========================================================================
    console.log('âš–ï¸ Creating consistency rules...');

    // Sheldon forbidden words rule
    app.database.createConsistencyRule({
      projectId: project.id,
      name: 'Sheldon Forbidden Words',
      description: 'Sheldon has NO meta-knowledge. Cannot use forbidden terms in his POV.',
      category: 'character_knowledge',
      severity: 'critical',
      ruleType: 'forbidden_word',
      config: {
        characterId: sheldon.id,
        words: SHELDON_FORBIDDEN_WORDS,
        replacements: {
          'benefactor': ['the system', 'the presence', 'whatever brought him here'],
          'Cosmos': ['his benefactor', 'the presence'],
          'perk': ['ability', 'skill', 'gift']
        }
      },
      enabled: true,
      tags: ['sheldon', 'pov', 'knowledge']
    });
    console.log('   âœ“ Sheldon forbidden words rule');

    // Ryoko timeline lock rule
    app.database.createConsistencyRule({
      projectId: project.id,
      name: 'Ryoko Sealed Until Obon 2001',
      description: 'Ryoko cannot physically appear before August 13, 2001 (first day of Obon). Astral projection observation is permitted.',
      category: 'character_state',
      severity: 'critical',
      ruleType: 'timeline_lock',
      config: {
        characterId: 'ryoko',
        cannotAppearBefore: EXTENDED_LOCKS.RYOKO_RELEASE,
        reason: 'Ryoko is sealed in the cave until Tenchi releases her',
        exceptions: ['astral_projection', 'observation_only']
      },
      enabled: true,
      tags: ['ryoko', 'timeline', 'canonical-lock']
    });
    console.log('   âœ“ Ryoko timeline lock rule');

    // Canon mother rule
    app.database.createConsistencyRule({
      projectId: project.id,
      name: 'OVA Canon Mother',
      description: 'Tenchi\'s mother is Kiyone Masaki, NOT Achika. Any reference to "Achika" as Tenchi\'s mother is a canon violation.',
      category: 'canon_compliance',
      severity: 'critical',
      ruleType: 'forbidden_word',
      config: {
        context: 'tenchi_mother',
        forbiddenTerms: ['Achika'],
        correctTerms: ['Kiyone Masaki', 'Kiyone'],
        reason: 'Achika is Tenchi Universe only. OVA canon mother is Kiyone Masaki.'
      },
      enabled: true,
      tags: ['canon', 'kiyone', 'mother', 'critical']
    });
    console.log('   âœ“ OVA canon mother rule (Kiyone, not Achika)');

    // Kiyone Makibi exclusion rule
    app.database.createConsistencyRule({
      projectId: project.id,
      name: 'Kiyone Makibi Does Not Exist',
      description: 'Kiyone Makibi (Mihoshi\'s Galaxy Police partner) does NOT exist in OVA canon. She was created for Tenchi Universe only.',
      category: 'canon_compliance',
      severity: 'critical',
      ruleType: 'forbidden_character',
      config: {
        characterName: 'Kiyone Makibi',
        reason: 'Character does not exist in OVA canon. Created by Naoko Hasegawa for spin-off novels and Tenchi Universe.'
      },
      enabled: true,
      tags: ['canon', 'kiyone-makibi', 'forbidden', 'critical']
    });
    console.log('   âœ“ Kiyone Makibi exclusion rule (does not exist in OVA)\n');

    // ========================================================================
    // RUN INITIAL CONSISTENCY CHECK
    // ========================================================================
    console.log('ðŸ” Running initial consistency check...');
    const checkResult = app.checkConsistency();
    console.log(`   Health Score: ${checkResult.healthScore.toFixed(1)}/100`);
    console.log(`   Violations: ${checkResult.summary.total}`);
    if (checkResult.summary.critical > 0) {
      console.log(`   âš ï¸  Critical: ${checkResult.summary.critical}`);
    }
    console.log('');

    // ========================================================================
    // SUMMARY
    // ========================================================================
    console.log('â•'.repeat(60));
    console.log('âœ… Son of Cosmos database seeding complete (CORRECTED)!\n');
    console.log('Created:');
    console.log(`   â€¢ 1 Project`);
    console.log(`   â€¢ 4 Species with aging curves`);
    console.log(`   â€¢ 6 Characters (including Kiyone Masaki & Tennyo)`);
    console.log(`   â€¢ 15+ Canonical facts (locked)`);
    console.log(`   â€¢ 5+ Family relationships`);
    console.log(`   â€¢ 2 Containers (Book 1, Chapter 1)`);
    console.log(`   â€¢ 1 Scene (Day 1 placeholder)`);
    console.log(`   â€¢ 4 Consistency rules`);
    console.log('');
    console.log('CORRECTIONS APPLIED:');
    console.log('   â€¢ Yosho birth: 300 CE â†’ ~1262 CE');
    console.log('   â€¢ Nobuyuki birth: 1955 â†’ ~1869');
    console.log('   â€¢ Nobuyuki species: Human â†’ Hybrid');
    console.log('   â€¢ Wife reference: Achika â†’ Kiyone Masaki');
    console.log('   â€¢ Added Kiyone Masaki (deceased mother)');
    console.log('   â€¢ Added Tennyo Masaki (older sister)');
    console.log('   â€¢ Added Juraian (Unbonded) species');
    console.log('   â€¢ Added canon compliance rules');
    console.log('');
    console.log(`Database: ./son_of_cosmos.db`);
    console.log('â•'.repeat(60));

    // Close database
    app.close();

  } catch (error) {
    console.error('âŒ Seeding failed:', error);
    process.exit(1);
  }
}

// ============================================================================
// RUN
// ============================================================================

seedDatabase().catch(console.error);
